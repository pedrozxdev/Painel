/**
 * CustomerFlow Router - Gerenciador de Rotas SPA
 */

import { initDashboardCharts, renderCustomerList } from "./app.js";

// Definição das visualizações (Templates)
const routes = {
    "dashboard": {
        title: "Dashboard",
        render: () => `
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 animate-fadeIn">
                <div class="p-6 bg-white dark:bg-darkCard rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
                    <p class="text-sm text-gray-500 uppercase">Total de Clientes</p>
                    <h2 id="stats-total-customers" class="text-3xl font-bold mt-2">...</h2>
                    <span class="text-green-500 text-sm font-medium"><i class="fas fa-arrow-up"></i> Atualizado agora</span>
                </div>
                <div class="p-6 bg-white dark:bg-darkCard rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
                    <p class="text-sm text-gray-500 uppercase">Taxa de Conversão</p>
                    <h2 class="text-3xl font-bold mt-2">18.5%</h2>
                </div>
                <div class="p-6 bg-white dark:bg-darkCard rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
                    <p class="text-sm text-gray-500 uppercase">Status do Sistema</p>
                    <h2 class="text-3xl font-bold mt-2 text-green-500 text-lg">Online</h2>
                </div>
            </div>
            <div class="mt-8 p-6 bg-white dark:bg-darkCard rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
                <h3 class="font-bold mb-4">Fluxo de Novos Clientes</h3>
                <div class="h-64">
                    <canvas id="mainChart"></canvas>
                </div>
            </div>
        `,
        afterRender: () => {
            initDashboardCharts();
        }
    },
    "customers": {
        title: "Gestão de Clientes",
        render: () => `
            <div class="bg-white dark:bg-darkCard rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden animate-fadeIn">
                <div class="p-4 border-b dark:border-gray-700 flex flex-col sm:flex-row justify-between items-center gap-4">
                    <h3 class="font-bold">Diretório de Clientes</h3>
                    <button onclick="window.showCustomerModal()" class="w-full sm:w-auto bg-primary text-white px-6 py-2 rounded-lg text-sm font-bold shadow-lg shadow-blue-500/30">
                        <i class="fas fa-plus mr-2"></i> Adicionar Cliente
                    </button>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <thead class="bg-gray-50 dark:bg-gray-800 text-xs uppercase text-gray-500">
                            <tr>
                                <th class="px-6 py-4">Cliente</th>
                                <th class="px-6 py-4">E-mail</th>
                                <th class="px-6 py-4">Ações</th>
                            </tr>
                        </thead>
                        <tbody id="customer-table-body" class="divide-y dark:divide-gray-700 text-sm">
                            <tr><td colspan="3" class="p-10 text-center">Carregando clientes...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        `,
        afterRender: () => {
            renderCustomerList();
        }
    },
    "reports": {
        title: "Relatórios e Exportação",
        render: () => `
            <div class="max-w-2xl mx-auto bg-white dark:bg-darkCard rounded-2xl p-8 text-center border border-gray-100 dark:border-gray-700 animate-fadeIn">
                <div class="w-20 h-20 bg-blue-100 dark:bg-blue-900/30 text-primary rounded-full flex items-center justify-center mx-auto mb-6">
                    <i class="fas fa-file-pdf text-3xl"></i>
                </div>
                <h3 class="text-2xl font-bold mb-2">Relatório Geral de Clientes</h3>
                <p class="text-gray-500 dark:text-gray-400 mb-8">
                    Gere um documento PDF completo contendo a lista atualizada de clientes, status e datas de cadastro diretamente do seu banco de dados Firestore.
                </p>
                <button onclick="window.generatePDFReport()" class="bg-slate-900 dark:bg-primary text-white px-8 py-3 rounded-xl font-bold transition-transform active:scale-95">
                    <i class="fas fa-download mr-2"></i> Baixar PDF Estilizado
                </button>
            </div>
        `,
        afterRender: () => {}
    }
};

/**
 * Função principal de navegação
 * @param {string} path - Nome da rota
 */
export const navigate = (path) => {
    const route = routes[path] || routes["dashboard"];
    
    // Atualiza o DOM
    const contentArea = document.getElementById('content');
    const pageTitle = document.getElementById('page-title');
    
    if (contentArea) {
        contentArea.innerHTML = route.render();
        pageTitle.innerText = route.title;
        
        // Executa lógica adicional após renderizar o HTML
        route.afterRender();
        
        // Atualiza URL visualmente sem recarregar
        window.history.pushState({}, "", `#${path}`);
        
        // Atualiza estado ativo na navbar
        updateActiveLink(path);
    }
};

function updateActiveLink(path) {
    // Remove classes de todos os links e adiciona ao atual
    document.querySelectorAll('nav button, aside a').forEach(el => {
        el.classList.remove('text-primary');
    });
    // Lógica para marcar o ícone/texto ativo pode ser expandida aqui
}

// Escutar o botão "Voltar" do navegador
window.addEventListener('popstate', () => {
    const path = window.location.hash.replace('#', '') || 'dashboard';
    navigate(path);
});

// Inicialização Global
window.navigate = navigate; // Torna disponível para o HTML onclick

document.addEventListener('DOMContentLoaded', () => {
    const initialPath = window.location.hash.replace('#', '') || 'dashboard';
    navigate(initialPath);
});